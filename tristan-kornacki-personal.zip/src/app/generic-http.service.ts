import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { KEY } from './constants'
@Injectable({
  providedIn: 'root',
})
export class GenericHttpService<T> {
  constructor(private httpClient: HttpClient, private url: string) {}
  public getOne(location: string): Observable<T[]> {
      return this.httpClient.get<T[]>(`${this.url}?q=${location}&${KEY}`);
  }
} // GenericHttpService
