import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BASEURL } from '../constants';
import { Weather } from './weather';
import { GenericHttpService } from '../generic-http.service';
@Injectable({
  providedIn: 'root',
})
export class WeatherService extends GenericHttpService<Weather> {
  constructor(public http: HttpClient) {
    super(http, `${BASEURL}`);
  }
}
