import { catchError } from 'rxjs/operators';
import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { Observable, of, Subscription} from 'rxjs';
import { Weather } from '../weather';
import { WeatherService } from '../weather.service'
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
    selector: 'app-product',
    templateUrl: 'weather-detail.component.html',
})

export class WeatherDetailComponent implements OnInit {
    found:boolean;
    selectedWeather: Weather;
    weather$: Observable<Weather[]>;
    msg:string;
    subscription: Subscription;

    weatherForm: FormGroup;
    location: FormControl;
    constructor(
        private weatherService: WeatherService,
        private builder: FormBuilder){
        this.location = new FormControl(
            '',
            Validators.compose([Validators.required])
            );
    }

    ngOnInit(): void {
        this.selectedWeather = null;
        this.msg = '';
        this.found = false;

        this.weatherForm = this.builder.group({
            location: this.location
        })
        this.getDefaultLocationWeather();
    }

    getDefaultLocationWeather(): void {
        this.getWeather("Toronto");
    }

    getWeather(location:string): void {
        this.weather$ = this.weatherService.getOne(location).pipe(
            catchError(error => {
                if (error.error instanceof ErrorEvent) {
                    this.msg = `Error: ${error.error.message}`;
                } else {
                    this.msg = `Error: ${error.message}`;
                }
                return of([]);
            })
        );
    }

    updateSelectedWeather(): void{

    }

    onLocationEntered(): void {
        const xSubscr = this.weatherForm.get('location').valueChanges.subscribe(val => {
            console.log("val")
            console.log(val)
        });
        this.subscription.add(xSubscr);
    }


    ngOnDestroy(): void {
        // this.subscription.unsubscribe();
    } // ngOnDestroy
}