import { Component, OnInit, ViewChild, Input } from '@angular/core';
@Component({
    selector: 'app-product',
    templateUrl: 'api-home.component.html',
  })
export class ApiComponent implements OnInit {
    ngOnInit(): void {
    }
}