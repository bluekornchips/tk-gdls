import { Component, OnInit, ViewChild, Input } from '@angular/core';
@Component({
    selector: 'app-product',
    templateUrl: 'requirements-home.component.html',
  })
export class RequirementsComponent implements OnInit {
    ngOnInit(): void {
    }
}