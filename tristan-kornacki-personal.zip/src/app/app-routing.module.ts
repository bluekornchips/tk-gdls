import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ApiComponent } from './api/api-home.component';
import { HomeComponent } from './home/home.component';
import { RequirementsComponent } from './requirements/requirements-home.component';
import { WeatherDetailComponent } from './weather/weather-detail/weather-detail.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'weather', component: WeatherDetailComponent },
  { path: 'requirements', component: RequirementsComponent }, 
  { path: 'api', component: ApiComponent }, 
  { path: '', component: HomeComponent }
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
