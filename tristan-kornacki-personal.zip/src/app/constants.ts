export const BASEURL = 'http://api.weatherapi.com/v1/current.json?';
export const KEY = "96f65fe8d37d429885a03834212901";