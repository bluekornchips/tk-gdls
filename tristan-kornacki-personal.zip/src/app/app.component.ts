import { Component } from '@angular/core';
@Component({
  selector: 'app-assignment',
  templateUrl: './app.component.html',
})
export class AppComponent {}
