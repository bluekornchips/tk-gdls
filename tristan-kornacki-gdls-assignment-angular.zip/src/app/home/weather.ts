import { IWeather } from "../interface/iweather";

export class Weather implements IWeather {
    location: {
        name: string,
        region: string
        country: string,
        lat: number,
        lon: number,
        tz_id: string,
        localtime_epoch: number,
        localtime: string
    };
    current: {
        last_updated_epoch: number,
        last_updated: number,
        temp_c: number,
        temp_f: number,
        is_day: number,
        condition: {
            text: string,
            icon: string
            code: number
        },
        wind_mph: number,
        wind_kph: number,
        wind_degree: number,
        wind_dir: string,
        pressure_mb: number,
        pressure_in: number,
        precip_mm: number,
        precip_in: number,
        humidity: number,
        cloud: number,
        feelslike_c: number,
        feelslike_f: number,
        vis_km: number,
        vis_miles: number,
        uv: number,
        gust_mph: number,
        gust_kph: number
    };
    constructor(){
        this.location = {
            name: "",
            region: "",
            country: "",
            lat: 0,
            lon: 0,
            tz_id: "",
            localtime_epoch: 0,
            localtime: ""
        },
        this.current = {
            last_updated_epoch: 0,
            last_updated: 0,
            temp_c: 0,
            temp_f: 0,
            is_day: 0,
            condition: {
                text: "",
                icon: "",
                code: 0
            },
            wind_mph: 0,
            wind_kph: 0,
            wind_degree: 0,
            wind_dir: "",
            pressure_mb: 0,
            pressure_in: 0,
            precip_mm: 0,
            precip_in: 0,
            humidity: 0,
            cloud: 0,
            feelslike_c: 0,
            feelslike_f: 0,
            vis_km: 0,
            vis_miles: 0,
            uv: 0,
            gust_mph: 0,
            gust_kph: 0
        };
    }
}
