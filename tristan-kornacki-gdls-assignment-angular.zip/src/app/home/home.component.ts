import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { WeatherService } from '../service/weather-service';
import { Weather } from './weather';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})

export class HomeComponent implements OnInit {
  @ViewChild(MatSort) sort: MatSort;
  displayedColumns: string[] = ['Name', 'Region', 'Country', 'Temp', 'Condition'];
  weather: Weather;
  public userWeathers: Weather[];
  locationString: string = "";
  weatherForm: FormGroup;
  enteredLocation: FormControl;
  dataSource: MatTableDataSource<Weather>;
  constructor(private builder: FormBuilder, public weatherService: WeatherService) {
    this.enteredLocation = new FormControl(
      '',
      Validators.compose([Validators.required])
    );
   }

  ngOnInit(): void {
    this.weatherForm = this.builder.group({
      enteredLocation: this.locationString
    })
    this.weatherForm.patchValue({
      enteredLocation: this.locationString
    })
    this.dataSource = new MatTableDataSource([]);
    this.refreshDS();
  }

  getLocationWeather(){
    this.weatherService.getByLocation(this.weatherForm.value.enteredLocation).subscribe(payload => {
      if(payload != undefined){
        this.weather = payload
      }
      else{
        
      }
    })
   this.refreshDS();
  }

  refreshDS(){
    this.dataSource = new MatTableDataSource([this.weather]);
  }
}
