import { WeatherService } from './weather-service';

describe('WeatherService', () => {
  it('should create an instance', () => {
    expect(new WeatherService()).toBeTruthy();
  });
});
