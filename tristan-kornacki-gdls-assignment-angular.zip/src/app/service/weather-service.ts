import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { GenericHttpService } from "../generic-http.service";
import { Weather } from "../home/weather";

@Injectable({
    providedIn: 'root'
  })
export class WeatherService extends GenericHttpService<Weather> {
    constructor(public http: HttpClient){
        super(http)
    }
}
