import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './requirements.component.html',
  styles: [],
})
export class RequirementsComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}