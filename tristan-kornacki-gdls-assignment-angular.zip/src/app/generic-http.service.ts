import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { KEY, WEATHERURL } from './constants';

@Injectable({
  providedIn: 'root',
})
export class GenericHttpService<T> {
  constructor(private httpClient: HttpClient) {}
  public getByLocation(loc: string): Observable<T> {
    return this.httpClient.get<T>(`${WEATHERURL}${loc}&key=${KEY}`);
  } // getById
} // GenericHttpService
