export const BASEURL = 'http://localhost:4200/';
export const WEATHERURL = 'http://api.weatherapi.com/v1/current.json?q='
export const KEY = '96f65fe8d37d429885a03834212901'